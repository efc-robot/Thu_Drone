Pull in a recent version of Eigen from upstream or find a system installation
```
<build_depend>eigen_catkin</build_depend>
```

To debug or analyze the effects of this library on your catkin workspace : https://github.com/ethz-asl/eigen_catkin_tools.

For an overview of the possible reasons for segfaults / compiler errors / other issues see this wikipage: https://github.com/ethz-asl/eigen_catkin/wiki/Eigen-Memory-Issues
